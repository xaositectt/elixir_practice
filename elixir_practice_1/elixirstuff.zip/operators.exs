IO.puts true and true
IO.puts !true
IO.puts !"what"
IO.puts false and "what the funk" #shouldn't acccept the second argument but it works because first one already determines the result
IO.puts 1 == 1.0
IO.puts 1 === 1.0

