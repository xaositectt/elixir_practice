{a, b, c} = {:hello, "world", 42}

IO.puts a
IO.puts b
IO.puts c

x = 2

IO.puts ^x = 2
