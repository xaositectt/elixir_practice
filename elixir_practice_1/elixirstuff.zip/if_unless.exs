a = "what the funk"
b = nil

if b do
  IO.puts "this works"
else
  IO.puts "or maybe it's false or nil"
end
